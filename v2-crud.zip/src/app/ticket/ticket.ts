export interface Ticket {
    id: number;
    code: string;
    date: string;
}
